package botanico;

import java.util.Objects;

public abstract class Planta {
    protected String nombre;
    protected String ubicacion;
    protected String clima;

    public Planta(String nombre, String ubicacion, String clima) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.clima = clima;
    }

    public String getNombre() {
        return nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public abstract String toString();
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true; // Verifica si es la misma instancia
        if (o == null || getClass() != o.getClass()) return false; // Verifica si es del mismo tipo
        Planta planta = (Planta) o;
        return nombre.equals(planta.nombre) && ubicacion.equals(planta.ubicacion); // Compara solo nombre y ubicacion
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, ubicacion); // genera hash solo con nmbre y ubicacion
    }
}
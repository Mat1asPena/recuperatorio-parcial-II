package botanico;

import java.util.ArrayList;
import java.util.List;

public class Jardin {
    private List<Planta> plantas;

    public Jardin() {
        plantas = new ArrayList<>();
    }

    public void agregarPlanta(Planta planta) throws PlantasIgualesException {
        // Verifica si ya existe una planta con el mismo nombre y ubicación en la lista
        for (Planta p : plantas) {
            if (p.equals(planta)) {
                throw new PlantasIgualesException("Ya existe una planta con el mismo nombre y ubicacion en el jardin.");
            }
        }
        plantas.add(planta); // Agrega la planta si no existe duplicado
    }

    public void mostrarPlantas() {
        for (Planta planta : plantas) {
            System.out.println(planta.toString());
        }
    }

    public void podarPlantas() {
        for (Planta planta : plantas) {
            if (planta instanceof Podable podable) {
                podable.podar();
            } else {
                System.out.println("La planta " + planta.getNombre() + " no se puede podar (Flor).");
            }
        }
    }
}
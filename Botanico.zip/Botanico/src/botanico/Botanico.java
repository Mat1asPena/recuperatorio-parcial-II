package botanico;

public class Botanico {
    public static void main(String[] args) {
        Jardin jardin = new Jardin();
        
        try {
            Arbol roble = new Arbol("Roble", "Zona Norte", "Templado", 15.0);
            Arbusto lavanda = new Arbusto("Lavanda", "Zona Sur", "Mediterraneo", 7);
            // Arbusto arbustoLanzarExepciones = new Arbusto("Lavanda", "Zona Sur", "Mediterraneo", 17);
            Flor rosa = new Flor("Rosa", "Zona Este", "Templado", Temporada.PRIMAVERA);

            jardin.agregarPlanta(roble);
            jardin.agregarPlanta(lavanda);
            jardin.agregarPlanta(rosa);
            
            System.out.println("Mostrando todas las plantas en el jardin:");
            jardin.mostrarPlantas();
            
            System.out.println("--------------------------------------------");

            System.out.println("\nPodando las plantas podables:");
            jardin.podarPlantas();
        } 
        
        catch (PlantasIgualesException | ExcepcionFollajeInvalido e) {
            System.out.println(e.getMessage());
        }
    }
}

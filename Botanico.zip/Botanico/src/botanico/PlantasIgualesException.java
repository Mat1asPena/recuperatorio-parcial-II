package botanico;

public class PlantasIgualesException extends Exception {
    public PlantasIgualesException(String mensaje) {
        super(mensaje);
    }
}

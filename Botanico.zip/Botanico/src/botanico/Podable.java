package botanico;

public interface Podable {
    void podar();
}

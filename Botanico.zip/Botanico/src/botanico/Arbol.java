package botanico;

public class Arbol extends Planta implements Podable {
    private double alturaMaxima;

    public Arbol(String nombre, String ubicacion, String clima, double alturaMaxima) {
        super(nombre, ubicacion, clima);
        this.alturaMaxima = alturaMaxima;
    }

    @Override
    public void podar() {
        System.out.println("Poda realizada en el arbol: " + nombre);
    }

    @Override
    public String toString() {
        return "Arbol - Nombre: " + nombre + ", Ubicacion: " + ubicacion + ", Clima: " + clima + ", Altura maxima: " + alturaMaxima + " metros";
    }
}
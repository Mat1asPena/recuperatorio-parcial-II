package botanico;

public class Arbusto extends Planta implements Podable {
    private int densidadFollaje;

    public Arbusto(String nombre, String ubicacion, String clima, int densidadFollaje) throws ExcepcionFollajeInvalido {
        super(nombre, ubicacion, clima);
        
        // Validación de que la densidad de follaje esté entre 1 y 10
        if (densidadFollaje < 1 || densidadFollaje > 10) {
            throw new ExcepcionFollajeInvalido("La densidad del follaje debe estar entre 1 y 10.");
        }
        
        this.densidadFollaje = densidadFollaje;
    }

    @Override
    public void podar() {
        System.out.println("Poda realizada en el arbusto: " + nombre);
    }

    @Override
    public String toString() {
        return "Arbusto - Nombre: " + nombre + ", Ubicacion: " + ubicacion + ", Clima: " + clima + ", Densidad del follaje: " + densidadFollaje;
    }
}

package botanico;

public enum Temporada {
    PRIMAVERA, VERANO, OTOÑO, INVIERNO;
}

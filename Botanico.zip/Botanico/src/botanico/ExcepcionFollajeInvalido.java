package botanico;

public class ExcepcionFollajeInvalido extends Exception {
    public ExcepcionFollajeInvalido(String mensaje) {
        super(mensaje);
    }
}
